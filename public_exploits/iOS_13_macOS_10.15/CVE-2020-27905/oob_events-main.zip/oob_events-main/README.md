## oob_events
The exploit uses two distinct vulnerabilities which I independently discovered and reported to Apple, CVE-2020-27905 which is a race condition leads to OOB read/write  via arbitrary 32-bit index,and CVE-2020-9964 which is a kernel  information leak bug.
