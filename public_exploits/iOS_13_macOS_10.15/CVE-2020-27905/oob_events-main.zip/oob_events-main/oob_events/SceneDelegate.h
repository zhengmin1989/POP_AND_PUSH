//
//  SceneDelegate.h
//  oob_events
//
//  Created by mg on 11/7/20.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

