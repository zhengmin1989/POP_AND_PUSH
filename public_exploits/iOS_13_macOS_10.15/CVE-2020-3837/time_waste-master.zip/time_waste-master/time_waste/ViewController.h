//
//  ViewController.h
//  time_waste
//
//  Created by Jake James on 2/22/20.
//  Copyright © 2020 Jake James. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

