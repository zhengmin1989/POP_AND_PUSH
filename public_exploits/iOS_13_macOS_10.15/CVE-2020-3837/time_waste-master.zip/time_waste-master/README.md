# time_waste

iOS 12.0-13.3 tfp0 for all devices (in theory) using heap overflow bug by Brandon Azad (CVE-2020-3837) and cuck00 info leak by Siguza (will probably remove in the future). Exploitation is mostly the same as oob_timestamp with a few differences. The main difference is that this one does not rely on hardcoded addresses and thus should be more reliable. The rest of the code is under GPL (exception given to the unc0ver team)
