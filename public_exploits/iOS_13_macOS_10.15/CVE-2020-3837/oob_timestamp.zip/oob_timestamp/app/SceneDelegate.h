//
//  SceneDelegate.h
//  oob_timestamp
//
//  Created by Brandon Azad on 1/30/20.
//  Copyright © 2020 Brandon Azad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

