//
//  ViewController.m
//  oob_timestamp
//
//  Created by Brandon Azad on 1/30/20.
//  Copyright © 2020 Brandon Azad. All rights reserved.
//

#import "ViewController.h"

#import "oob_timestamp.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
		oob_timestamp();
		usleep(100000);
		exit(1);
	});
}


@end
