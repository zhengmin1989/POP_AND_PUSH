/*
 * oob_timestamp.h
 * Brandon Azad
 */
#ifndef OOB_TIMESTAMP__OOB_TIMESTAMP__H_
#define OOB_TIMESTAMP__OOB_TIMESTAMP__H_

void oob_timestamp(void);

#endif
