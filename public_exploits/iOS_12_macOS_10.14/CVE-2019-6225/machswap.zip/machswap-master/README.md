# machswap

An iOS kernel exploit for iOS 11 - 12.1.2. Based on the task_swap_mach_voucher bug (CVE-2019-6225), joint-discovered/released by @S0rryMyBad and @bazad. Somewhat loosely based on @s1guza's v0rtex exploit.

Non-SMAP (<=A9) devices only.

Many thanks to @s1guza, @littlelailo, and @qwertyoruiopz. 

Writeup: https://sparkes.zone/blog/ios/2019/04/30/machswap-ios-12-kernel-exploit.html

Twitter: https://twitter.com/iBSparkes 
