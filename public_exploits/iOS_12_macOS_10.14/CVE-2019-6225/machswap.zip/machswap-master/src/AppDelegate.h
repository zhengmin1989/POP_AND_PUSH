//
//  AppDelegate.h
//  machswap
//
//  Created by Ben on 23/01/2019.
//  Copyright © 2019 Ben. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

