//
//  ViewController.h
//  machswap
//
//  Created by Ben on 23/01/2019.
//  Copyright © 2019 Ben. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property(nonatomic, strong) UINavigationController *nav;

- (id)initWithNav:(UINavigationController *)nav;

@end

