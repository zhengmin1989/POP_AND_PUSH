# v3ntex
Much like v1ntex, but with pipes and for iOS 12.

---

- tested on 12.1.2
- works up to 12.1.2
- gets you tfp0

##### Make sure to connect a lightning to headphone jack adapter prior to running this on a device without headphone jack!   
It is by no means necessary, but adds the missing flair ;)


Offsets hardcoded for:
 ```Darwin Kernel Version 18.2.0: Mon Nov 12 20:31:59 PST 2018; root:xnu-4903.232.2~1/RELEASE_ARM64_S5L8960X```   
Get your own if you wanna run it on something else ;)

Note:  
Exploit can probably be slightly improved to replace at least one non-deterministic component.
Might look into it some time.

Special thanks to:  
@S0rryMybad  
@s1guza  
@_bazad
