/*
 * voucher_swap.h
 * Brandon Azad
 */
#ifndef VOUCHER_SWAP__VOUCHER_SWAP_H_
#define VOUCHER_SWAP__VOUCHER_SWAP_H_

/*
 * voucher_swap
 *
 * Description:
 * 	Run the voucher_swap exploit.
 */
void voucher_swap(void);

#endif
