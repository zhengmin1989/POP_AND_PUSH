//
//  ViewController.m
//  SockPuppet
//
//  Created by Ned Williamson on 7/10/19.
//  Copyright © 2019 Ned Williamson. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


@end
