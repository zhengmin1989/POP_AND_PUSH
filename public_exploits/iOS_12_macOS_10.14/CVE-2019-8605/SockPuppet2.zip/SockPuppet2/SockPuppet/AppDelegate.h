//
//  AppDelegate.h
//  SockPuppet
//
//  Created by Ned Williamson on 7/10/19.
//  Copyright © 2019 Ned Williamson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

