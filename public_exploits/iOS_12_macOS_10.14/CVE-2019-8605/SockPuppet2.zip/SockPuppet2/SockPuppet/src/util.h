// <3 nedwill 2019
#ifndef UTIL_H_
#define UTIL_H_

#include <stdint.h>

bool LooksLikeKaddr(uint64_t addr);

#endif /* UTIL_H_ */
