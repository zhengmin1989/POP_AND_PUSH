#ifndef sploit_h
#define sploit_h

void vfs_sploit(void);

#endif
