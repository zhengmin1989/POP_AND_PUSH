#ifndef sploit_h
#define sploit_h

void go(void);

#endif
