//
//  jailbreak.h
//  multipath_kfree
//
//  Created by John Åkerblom on 6/1/18.
//

#ifndef jailbreak_h
#define jailbreak_h

void jb_go(void);

#endif /* jailbreak_h */
