
int snapshot_count(const char *path);
int mount_unionfs(const char *dmg_path);
int remount_root_fs(void);
