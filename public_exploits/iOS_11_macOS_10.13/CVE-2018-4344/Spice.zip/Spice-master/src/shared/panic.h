#ifndef PANIC_H
#define PANIC_H

__attribute__((noreturn)) void do_panic(void);

#endif
