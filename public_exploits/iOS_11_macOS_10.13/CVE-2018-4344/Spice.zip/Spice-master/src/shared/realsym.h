#ifndef REALSYM_H
#define REALSYM_H
uint64_t realsym(const char *file, const char *sym);
#endif
