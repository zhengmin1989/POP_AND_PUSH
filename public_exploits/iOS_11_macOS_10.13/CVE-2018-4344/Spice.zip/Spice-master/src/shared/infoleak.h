#ifndef INFOLEAK_H
#define INFOLEAK_H

#include "common.h"

kptr_t get_kernel_slide(void);

#endif
