
void suspend_all_threads(void);
void resume_all_threads(void);
void respring(void);
int execprog(const char *prog, const char* args[]);
bool extractDeb(NSString *debPath);
