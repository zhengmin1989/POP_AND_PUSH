#ifndef INSTALL_H
#define INSTALL_H

int install(const char *config_path, const char *racoon_path, const char *dyld_cache_path);

#endif
