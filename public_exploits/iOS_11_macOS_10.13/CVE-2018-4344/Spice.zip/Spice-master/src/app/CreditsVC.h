#import <UIKit/UIKit.h>

@interface CreditsVC : UIViewController

- (id)init;

@end
