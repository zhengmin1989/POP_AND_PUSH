#import <UIKit/UIKit.h>

@interface MainVC : UIViewController

- (id)init;

- (void)actionJailbreak;

@end
