#ifndef async_wake_h
#define async_wake_h

#include <stdio.h>

void go(void);

#endif /* async_wake_h */
