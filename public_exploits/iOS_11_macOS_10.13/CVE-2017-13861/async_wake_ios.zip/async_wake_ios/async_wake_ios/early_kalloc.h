#ifndef early_kalloc_h
#define early_kalloc_h

#include <stdint.h>

uint64_t early_kalloc(int size);

#endif
